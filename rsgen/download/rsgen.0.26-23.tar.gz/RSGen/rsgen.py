class ModuleError(Exception):pass
def import_error(module):
    raise ModuleError(f"The module: {module} it is not installed.\n\
        You must install the necessary libraries for the correct functioning of Python RSGen.\n\
        Run the following command: pip install <rsgen-path>/requirements.txt")

try:import os
except:import_error("Netifaces")

class Checks:

    def __init__(self) -> None:
        
        Checks.check_modules()
        Checks.check_os(Checks.get_os())

    def check_modules():
        try:import customtkinter
        except:import_error("CustomTkinter")
        try:import socket
        except:import_error("Socket")
        try:import netifaces
        except:import_error("Netifaces")
        try:import threading
        except:import_error("Netifaces")
        try:import requests
        except:import_error("Requests")
        try:import pyperclip
        except:import_error("PyPerClip")
        try:import datetime
        except:import_error("DateTime")
        try:
            import tkinter
            import tkinter as tk
        except:import_error("Tkinter")
        try:import inspect
        except:import_error("Inspect")
        try:from PIL import Image
        except:import_error("Pillow")
        try:import webbrowser
        except:import_error("WebBrowser")
    
    def get_os():return os.name
    def check_os(current_os):
        if current_os == 'Linux':pass
        else:print(f"{current_os} may give compatibility problems.")
    
if __name__ == '__main__':

    Checks()

    from main import RSGeneratorApp
    RSGeneratorApp().mainloop() 