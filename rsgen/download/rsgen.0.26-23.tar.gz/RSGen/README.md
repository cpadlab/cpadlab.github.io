# Reverse Sheell Generator (RSGen)

## Code by 14Wual - [WebVersion](https://14wual.github.io/rsgen/)

## Install

```
wget -O - https://14wual.github.io/rsgen/download/rsgen.0.26-23.tar.gz | tar -xz
cd rsgen && pip install requirements.txt
```

```
git clone https://github.com/14wual/rsgen.git && cd rsgen
pip install requirements.txt
```

## Usage

**Note**: `cat how.txt`

```
python3 rsgen.py
```

## Shells Avilable

1. bash
1. perl
1. php
1. python
1. ruby
1. golang
1. netcat
1. ncat
1. powershell
1. awk
1. java
1. telnet
1. lua
1. nodejs
1. groovy

## Gallery

[!screenshot](https://14wual.github.io/rsgen/img/rsgen-screenshot.png)