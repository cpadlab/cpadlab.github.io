import setuptools
import io, os

current_dir = os.path.abspath(os.path.dirname(__file__))
with io.open(os.path.join(current_dir, "README.md"), encoding="utf-8") as fd:
    desc = fd.read()

# Version format: <major version>.<revision><month>
VERSION = "0.26"

setuptools.setup(
    name="rsgen",
    version=VERSION,
    author="Carlos Padilla",
    author_email="cpadlab@gmail.com",
    description="Reverse Sheell Generator",
    long_description=desc,
    long_description_content_type="text/markdown",
    url="https://14wual.github.io/rsgen",
    packages=setuptools.find_packages(),
    package_data={"dirsearch": ["*", "modules/*", "src/*"]},
    include_package_data=True,
    python_requires=">=3.7",
    install_requires=[
        "customtkinter>=5.1.3",
        "netifaces>=0.11.0",
        "requests>=2.28.1",
        "pyperclip>=1.8.2",
    ],
    classifiers=[
        "Programming Language :: Python",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: GNU GENERAL PUBLIC LICENSE",
        "Operating System :: OS Linux",
        "Topic :: Security",
        "Programming Language :: Python :: 3.11",
    ],
    keywords=["sheells", "reverse_shells", "pentesting", "security"],
)