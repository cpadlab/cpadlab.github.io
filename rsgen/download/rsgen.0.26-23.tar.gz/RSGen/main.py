import customtkinter

from modules.common import Common

class RSGeneratorApp(customtkinter.CTk):

    def __init__(self):
        super().__init__()

        print("RSGenerator - Code By 14WUAL")
        print("Version:  RSG V 0.0.26 | Jun2023")
        print("Welcome!")

        self.title("Reverse Shell Generator")
        self.geometry("517x783")
        self.maxsize(width=635, height=794)
        self.minsize(width=517, height=783)
        self.grid_columnconfigure(0, weight=1)
        
        self.colormain = "#8338ec"
        self.color_hover = "#7421ea"
        self.color_optionbtn = "#8338ec"
        
        self.rs_selected = 'Bash'

        self.line = 1

        Common(self)

        for column in range(5):self.grid_columnconfigure(column, weight=1)