import datetime, netifaces
import requests, socket
import threading

def select_list():
    return ["Awk", "Bash", "Golang", "Groovy", "Java", "Lua", "Ncat", "Netcat", "NodeJS", "Perl", "PHP", "Powershell", "Python", "Ruby", "Telnet"]


def get_private_ip():

    interfaces = netifaces.interfaces()

    for interface in interfaces:
        addresses = netifaces.ifaddresses(interface)
        if netifaces.AF_INET in addresses:
            for address in addresses[netifaces.AF_INET]:
                if 'addr' in address:
                    ip = address['addr']
                    if not ip.startswith("127."):return ip

    return 500

def get_public_ip():

    ip_public = 500

    def fetch_ip():
        nonlocal ip_public

        try:
            response = requests.get('https://api.ipify.org?format=json', timeout=5)
            if response.status_code == 200:
                data = response.json()
                ip_public = data['ip']
            else:ip_public = 500
        except requests.RequestException:ip_public = 500

    thread = threading.Thread(target=fetch_ip)

    thread.start()
    thread.join(timeout=5)

    if thread.is_alive():ip_public = 500

    return ip_public

def get_localhost():

    try:ipv4 = socket.gethostbyname_ex(socket.gethostname())[-1][0]
    except socket.error as error:ipv4 = 500
    finally:return ipv4

def get_vpn_ip():
        
    interfaces = netifaces.interfaces()

    for interface in interfaces:
        if interface == "tun0":
            addresses = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addresses:
                for address in addresses[netifaces.AF_INET]:
                    if 'addr' in address:
                        ip = address['addr'];return ip
                    
    return "VPN Disconnected"