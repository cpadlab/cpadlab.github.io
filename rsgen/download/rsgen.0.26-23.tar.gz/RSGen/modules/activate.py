import customtkinter,inspect

def select_callback(self):
    self.rs_selected = self.select_shell_var.get()
    Activate.update_rs(self)

class Activate:

    def remove_grids(self):

        try:
            self.rs_bash_label_frame.grid_forget()
            self.rdbtn_frame.grid_forget()
            self.rs_netcat_label_frame.grid_forget()
            self.rdbtn_frame_1.grid_forget()
            self.rs_perl_label_frame.grid_forget()
            self.rs_python_label_frame.grid_forget()
            self.rs_php_label_frame.grid_forget()
            self.rs_ruby_label_frame.grid_forget()
            self.rs_golang_label_frame.grid_forget()
            self.rs_netcat_label_frame.grid_forget()
            self.rdbtn_frame_1.grid_forget()
            self.rs_ncat_label_frame.grid_forget()
            self.rdbtn_frame_2.grid_forget()
            self.rs_powershell_label_frame.grid_forget()
            self.rs_awk_label_frame.grid_forget()
            self.rs_java_label_frame.grid_forget()
            self.rs_telnet_label_frame.grid_forget()
            self.rs_lua_label_frame.grid_forget()
            self.rs_nodejs_label_frame.grid_forget()
            self.rs_groovy_label_frame.grid_forget()
            self.no_option_frame.grid_forget()
            self.no_option_label.grid_forget()
        except:pass

    def update_rs(self):
                
        from modules.shells.bash import rs_bash
        from modules.shells.perl import rs_perl
        from modules.shells.php import rs_php
        from modules.shells.python import rs_python
        from modules.shells.ruby import rs_ruby
        from modules.shells.golang import rs_golang
        from modules.shells.netcat import rs_netcat
        from modules.shells.ncat import rs_ncat
        from modules.shells.powershell import rs_powershell
        from modules.shells.awk import rs_awk
        from modules.shells.java import rs_java
        from modules.shells.telnet import rs_telnet
        from modules.shells.lua import rs_lua
        from modules.shells.nodejs import rs_nodejs
        from modules.shells.groovy import rs_groovy

        self.rs_frame = customtkinter.CTkFrame(self)

        try:self.rs_frame.grid_forget()
        except:pass
        finally:self.rs_frame.grid(row=8, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

        Reverse_Shells(self, self.rs_selected)

        classes_shells = {
            "Awk": rs_awk,
            "Bash": rs_bash,
            "Golang": rs_golang,
            "Groovy": rs_groovy,
            "Java": rs_java,
            "Lua": rs_lua,
            "Ncat": rs_ncat,
            "Netcat": rs_netcat,
            "NodeJS": rs_nodejs,
            "Perl": rs_perl,
            "PHP": rs_php,
            "Powershell": rs_powershell,
            "Python": rs_python,
            "Ruby": rs_ruby,
            "Telnet": rs_telnet
        }

        Activate.remove_grids(self)

        self.no_option_frame = customtkinter.CTkFrame(self.rs_frame)
        self.no_option_label = customtkinter.CTkLabel(self.no_option_frame, text="No Options Avilable")

        if self.rs_selected in classes_shells:
            classes_shells[self.rs_selected](self)

class Reverse_Shells:

    def __init__(self, RSGeneratorApp, shell) -> None:
        
        self = RSGeneratorApp

        for column in range(4):self.rs_frame.grid_columnconfigure(column, weight=1)
        self.rs_frame.grid_rowconfigure(2, weight=1)