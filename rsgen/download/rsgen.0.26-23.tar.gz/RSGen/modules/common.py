import customtkinter, webbrowser
from PIL import Image

from modules.get import get_private_ip, get_public_ip, get_localhost, get_vpn_ip
from modules.activate import Activate

class Common:

    def __init__(self, RSGeneratorApp) -> None:
        
        self = RSGeneratorApp

        self.select_shell_var = customtkinter.StringVar(value="Bash")

        Main_IP.ip_select(self)
        Main_PORT.port_select(self)

        Common.pre_content_loaded(self)

        Activate.update_rs(self)
        Common.footer(self)

    def footer(self):

        self.footer_frame = customtkinter.CTkFrame(self)
        self.footer_frame.grid(row=9, column=0, columnspan=4, padx=10, pady=(10,0), sticky="ew")

        label = customtkinter.CTkLabel(self.footer_frame, text="Code by 14WUAL © 2023 | DDBB: PentestMonkey ")
        label.grid(row=0, column = 0, pady=5, padx=5)

        self.footer_frame.grid_columnconfigure(0, weight=1)

        code_img = customtkinter.CTkImage(light_image=Image.open("src/terminal.png"),dark_image=Image.open("src/terminal.png"),size=(15, 15))
        ddbb_img = customtkinter.CTkImage(light_image=Image.open("src/database.png"),dark_image=Image.open("src/database.png"),size=(15, 15))
        heart_img = customtkinter.CTkImage(light_image=Image.open("src/heart.png"),dark_image=Image.open("src/heart.png"),size=(15, 15))
        follow_img = customtkinter.CTkImage(light_image=Image.open("src/following.png"),dark_image=Image.open("src/following.png"),size=(15, 15))
        web_img = customtkinter.CTkImage(light_image=Image.open("src/globe.png"),dark_image=Image.open("src/globe.png"),size=(15, 15))

        btn_code = customtkinter.CTkButton(self.footer_frame, text="", image=code_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://github.com/14wual/rsgen"))
        btn_ddbb = customtkinter.CTkButton(self.footer_frame, text="", image=ddbb_img, fg_color="transparent", width=20, height=20, hover=False,command=lambda:webbrowser.open("https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Reverse%20Shell%20Cheatsheet.md#revshells"))
        btn_heart = customtkinter.CTkButton(self.footer_frame, text="", image=heart_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://github.com/sponsors/14wual"))
        btn_follow = customtkinter.CTkButton(self.footer_frame, text="", image=follow_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://github.com/14wual"))
        btn_web = customtkinter.CTkButton(self.footer_frame, text="", image=web_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://14wual.github.io/rsgen"))

        btn_code.grid(row=0, column=2, pady=5, padx=5)
        btn_ddbb.grid(row=0, column=3, pady=5, padx=5)
        btn_heart.grid(row=0, column=4, pady=5, padx=5)
        btn_follow.grid(row=0, column=5, pady=5, padx=5)
        btn_web.grid(row=0, column=6, pady=5, padx=5)

    def pre_content_loaded(self):

        self.iplabel.grid(row=3, column=0, columnspan=4, padx=10, pady=(5,0), sticky="w")
        self.portlabel.grid(row=5, column=0, columnspan=4, padx=10, pady=(5,0), sticky="w")

        self.ip_select_frame.grid(row=4, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
        self.port_select_frame.grid(row=6, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

        self.custom_ip_entry.grid(row=0, column=0, padx=5, pady=5, sticky="nsew", columnspan=4)
        self.private_ip_btn.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        self.public_ip_btn.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        self.localhost_btn.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")
        self.vpn_ip_btn.grid(row=1, column=3, padx=5, pady=5, sticky="nsew")

        self.default_port_btn_1.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        self.default_port_btn_2.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        self.default_port_btn_3.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")
        self.default_port_btn_4.grid(row=1, column=3, padx=5, pady=5, sticky="nsew")

        self.port_select_minus.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        self.custom_port_entry.grid(row=0, column=1, padx=5, pady=5, sticky="nsew",  columnspan=2)
        self.port_select_plus.grid(row=0, column=3, padx=5, pady=5, sticky="nsew")

        self.port_label.grid(row=2, column=0, padx=5, pady=5, sticky="nsew", columnspan=4)
        self.ip_label.grid(row=2, column=0, padx=5, pady=5, sticky="nsew", columnspan=4)

class Main_IP:

    def ip_select(self):

        private_ip = get_private_ip()
        public_ip = get_public_ip()
        localhost = get_localhost()
        vpn_ip = get_vpn_ip()

        self.ip_selected = str(private_ip)

        if public_ip == 500:public_ip = 'Public IP Failed'
        if private_ip == 500:private_ip = 'Private IP Failed'
        if localhost == 500:localhost = 'Localhost IP Failed'

        self.iplabel = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=40), text="IP Select",justify="left",  text_color="#3D3B39")

        self.ip_select_frame = customtkinter.CTkFrame(self)
        for column in range(4):self.ip_select_frame.grid_columnconfigure(column, weight=1)

        self.custom_ip_entry = customtkinter.CTkEntry(self.ip_select_frame, placeholder_text="Enter a custom IP")
        self.private_ip_btn = customtkinter.CTkButton(self.ip_select_frame, text=private_ip, command=lambda ip=private_ip:Main_IP.ip_select_event(self, ip))
        self.public_ip_btn = customtkinter.CTkButton(self.ip_select_frame, text=public_ip, command=lambda ip=public_ip:Main_IP.ip_select_event(self, ip))
        self.localhost_btn = customtkinter.CTkButton(self.ip_select_frame, text=localhost, command=lambda ip=localhost:Main_IP.ip_select_event(self, ip))
        self.vpn_ip_btn = customtkinter.CTkButton(self.ip_select_frame, text=vpn_ip, command=lambda ip=vpn_ip:Main_IP.ip_select_event(self, ip))

        self.private_ip_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.public_ip_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.localhost_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.vpn_ip_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)

        self.ip_label = customtkinter.CTkLabel(master=self.ip_select_frame, text=f"IP Selected: {self.ip_selected}")

        self.custom_ip_entry.bind("<KeyRelease>", lambda event, self=self: Main_IP.update_custom_ip_entry(self))

    def update_custom_ip_entry(self):
        Common.ip_select_event(self, str(self.custom_ip_entry.get()))

    def ip_select_event(self, ip):

        self.ip_selected = str(ip)
        self.ip_label.configure(text=f"IP Selected: {self.ip_selected}")

        Activate.update_rs(self)

class Main_PORT:

    def port_select(self):

        self.plus_img = customtkinter.CTkImage(light_image=Image.open("src/plus.png"),dark_image=Image.open("src/plus.png"),size=(15, 15))
        self.minus_img = customtkinter.CTkImage(light_image=Image.open("src/minus.png"),dark_image=Image.open("src/minus.png"),size=(15, 15))

        self.port_selected = "1014"

        self.portlabel = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=40), text="Port Select", justify="left",  text_color="#3D3B39")

        self.port_select_frame = customtkinter.CTkFrame(self)
        for column in range(4):self.port_select_frame.grid_columnconfigure(column, weight=1)

        self.default_port_btn_1 = customtkinter.CTkButton(self.port_select_frame, text="1014", command=lambda port="1014":Main_PORT.port_select_event(self, port=port))
        self.default_port_btn_2 = customtkinter.CTkButton(self.port_select_frame, text="443", command=lambda port="443":Main_PORT.port_select_event(self, port=port))
        self.default_port_btn_3 = customtkinter.CTkButton(self.port_select_frame, text="1234", command=lambda port="1234":Main_PORT.port_select_event(self, port=port))
        self.default_port_btn_4 = customtkinter.CTkButton(self.port_select_frame, text="4242", command=lambda port="4242":Main_PORT.port_select_event(self, port=port))

        self.default_port_btn_1.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.default_port_btn_2.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.default_port_btn_3.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.default_port_btn_4.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        
        self.port_select_minus = customtkinter.CTkButton(self.port_select_frame, text="", command=lambda ip="-1":Main_PORT.calc_custom_port(self, ip),image=self.minus_img)
        self.custom_port_entry_var = customtkinter.StringVar(value=self.port_selected)
        self.custom_port_entry = customtkinter.CTkEntry(self.port_select_frame, textvariable=self.custom_port_entry_var, placeholder_text="Enter a custom Port")
        self.port_select_plus = customtkinter.CTkButton(self.port_select_frame, text="", command=lambda ip="+1":Main_PORT.calc_custom_port(self, ip),image=self.plus_img)

        self.port_select_minus.configure(fg_color=self.colormain, hover_color=self.color_hover)
        self.port_select_plus.configure(fg_color=self.colormain, hover_color=self.color_hover)

        self.port_label = customtkinter.CTkLabel(master=self.port_select_frame, text=f"Port Selected: {self.port_selected}")

        self.custom_port_entry.bind("<KeyRelease>", lambda event, self=self: Main_PORT.update_custom_port_entry(self))

    def calc_custom_port(self, calc):

        expression = str(self.port_selected) + str(calc)
        port = str(eval(expression))

        if int(port) > 65535:port = str(0)
        elif int(port) < 0:port = str(65535)
        else:pass

        Main_PORT.port_select_event(self, port=str(port))

    def update_custom_port_entry(self):
            
            port_value = self.custom_port_entry_var.get()

            if not all(char.isdigit() for char in port_value):
                self.custom_port_entry_var.set(value=self.port_selected)
                self.custom_port_entry.configure(value=self.port_selected)

            Main_PORT.port_select_event(self, port_value)

    def port_select_event(self, port):
            
            self.port_selected = str(port)
            self.port_label.configure(text=f"Port Selected: {self.port_selected}")

            self.custom_port_entry_var.set(value=self.port_selected)
            Activate.update_rs(self)