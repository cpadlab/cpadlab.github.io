# ██╗    ██╗██╗   ██╗ █████╗ ██╗     
# ██║    ██║██║   ██║██╔══██╗██║     
# ██║ █╗ ██║██║   ██║███████║██║     
# ██║███╗██║██║   ██║██╔══██║██║     
# ╚███╔███╔╝╚██████╔╝██║  ██║███████╗
#  ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝
#          (code by wual)

# VKM V5.0.6 | 2023 Summer Review 1
# Page >> https://14wual.github.io/vkm
# Code >> https://github.com/14wual/VKM
# Follow me >> https://twitter.com/14wual

import random

from modules.common.rot13 import Encrypt as e

global text_file
text_file = 'ddbb/usernames.txt'

class FA_ChooseUser:

    def get_random_line(file_name=text_file):

        with open(file_name, 'r') as file:
            lines = file.readlines()
            random_line = random.choice(lines)
        return e(random_line)